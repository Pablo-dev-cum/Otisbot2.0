exports.run = (client, message, args) => {
    message.channel.send("Tenes que tener una cancion puesta playazo");
    
  };
  